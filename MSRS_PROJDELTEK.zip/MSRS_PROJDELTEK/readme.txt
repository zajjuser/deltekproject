***WELCOME***

***LOGIN DETAILS***
USERNAME: admin
PASSWORD: admin123

http://localhost/MSRS_PROJDELTEK/

***HOME***
+Click on Home button to redirect to the Main Page 
+Displays "Now Showing" Movies 
+Can Reserve Seat for the selected movie 

***MOVIES***

+Click on Movies button to see all  Movies Showing
+Can Reserve Seat for the selected movie 
